const express = require("express");
const cors = require("cors");

require("./database/mongodbConnection");

const productRoutes = require("./controller/productController");
const customerRoutes = require("./controller/customerController");
const productCategoryRoutes = require("./controller/productCategoryController");
const productBrandRoutes = require("./controller/productBrandController");
const customerAddressRoutes = require("./controller/customerAddressController");
const productOrderRoutes = require("./controller/productOrderController");
const cartRoutes = require("./controller/cartController");
const orderRoutes = require("./controller/orderController");
const adminLoginRoutes = require("./controller/adminLoginController");
const adminHomeRoutes = require("./controller/adminHomeController");
const errorHandler = require("./middleware/errorHandler");

const app = express();
const PORT = process.env.PORT || 4040;

app.use(cors());
app.use(express.json());

app.use("/products", productRoutes.router);
app.use("/customers", customerRoutes.router);
app.use("/productcategories", productCategoryRoutes.router);
app.use("/productbrands", productBrandRoutes.router);
app.use("/customeraddresses", customerAddressRoutes.router);
app.use("/productorders", productOrderRoutes.router);
app.use("/adminlogin", adminLoginRoutes.router);
app.use("/carts", cartRoutes.router);
app.use("/orders", orderRoutes.router);
app.use("/adminhomeimages", adminHomeRoutes.router);

app.get("/health", (req, res) => {
  res.status(200).json({ status: "ok" });
});

app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
